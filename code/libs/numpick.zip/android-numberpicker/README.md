**This library is provided as-is and is not under active development**

A backport of the Android 4.2 NumberPicker.


Requires adding a single attribute to your theme. Check the sample app for how this is done.
